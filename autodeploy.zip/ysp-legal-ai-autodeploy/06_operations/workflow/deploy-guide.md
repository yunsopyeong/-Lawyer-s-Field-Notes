# 자동 배포 가이드

## 구조
GitHub push → Vercel 자동 배포 → 상담폼 서비스 반영

## 실행 순서
1. GitHub에 전체 파일 업로드
2. Vercel에서 저장소 연결
3. 환경변수 입력
4. Deploy 클릭
5. `main` 브랜치 push 시 자동 반영

## 환경변수
- OPENAI_API_KEY
- KAKAO_CHAT_URL
- NEXT_PUBLIC_KAKAO_CHAT_URL
- NEXT_PUBLIC_SITE_NAME
