# 윤소평 변호사 법률 AI 자동배포 시스템

이 저장소는 다음 기능을 한 번에 다루는 최소 실행형 구조입니다.

- 상담폼
- AI 사건 1차 분류 및 요약
- 카카오 상담 연결
- GitHub 연동
- Vercel 자동 배포
- 로컬 테스트용 Python 번들 생성기

## 배포 구조

GitHub에 push
→ Vercel이 자동 배포
→ 상담폼 접속
→ AI 분석 결과 표시
→ 카카오 상담 연결

## 빠른 시작

1. 이 저장소를 GitHub에 업로드합니다.
2. `web/.env.example`을 참고해 환경변수를 설정합니다.
3. Vercel에서 GitHub 저장소를 연결합니다.
4. `main` 브랜치에 push 하면 자동 배포됩니다.

## 필수 환경변수

- `OPENAI_API_KEY`
- `KAKAO_CHAT_URL`
- `NEXT_PUBLIC_KAKAO_CHAT_URL`
- `NEXT_PUBLIC_SITE_NAME`

## 로컬 실행

```bash
cd web
npm install
npm run dev
```

## 법률 안전장치

- 결과는 변호사 검토 전 임시 초안입니다.
- 자동 생성 결과만으로 최종 법률판단을 확정하지 않습니다.
- 민감정보는 공개 저장소에 올리지 않습니다.
