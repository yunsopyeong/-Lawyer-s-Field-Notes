from pathlib import Path
from datetime import datetime

OUTPUT = Path("output")
OUTPUT.mkdir(exist_ok=True)

def generate_summary(raw_text: str) -> str:
    return f"""# 상담 사건 요약

## 정보 수집
- 상담 입력: {raw_text}

## 분석
- 사건 유형은 추가 확인이 필요합니다.
- 제출자료와 사실관계에 따라 방향이 달라질 수 있습니다.

## 결론
- 이 초안은 변호사 검토 전 임시 결과물입니다.
"""

if __name__ == "__main__":
    text = "회사 채무가 많고 영업이 어렵습니다."
    output = generate_summary(text)
    path = OUTPUT / f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_summary.md"
    path.write_text(output, encoding="utf-8")
    print(path)
